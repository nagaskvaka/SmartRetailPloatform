const express = require("express");
const mongoose = require("mongoose");

const app = express();

const PORT = 3000;

app.use(express.json());

const mongoURL =
    process.env.MONGO_URL ||
    "mongodb://mongodb:27017/smartretail";

mongoose.connect(mongoURL)

.then(() => {

    console.log("Connected to MongoDB");

})

.catch((error) => {

    console.log("MongoDB connection failed");

    console.log(error);

});

const productSchema = new mongoose.Schema({

    name: String,
    category: String,
    price: Number

});

const Product = mongoose.model("Product", productSchema);

app.get("/", (req, res) => {

    res.send("Catalog Service Running");

});

app.post("/products", async (req, res) => {

    try {

        const product = new Product({

            name: req.body.name,
            category: req.body.category,
            price: req.body.price

        });

        await product.save();

        res.status(201).json({

            message: "Product Created",
            product: product

        });

    } catch (error) {

        res.status(500).json({

            error: error.message

        });

    }

});

app.get("/products", async (req, res) => {

    try {

        const products = await Product.find();

        res.json(products);

    } catch (error) {

        res.status(500).json({

            error: error.message

        });

    }

});

app.listen(PORT, () => {

    console.log(`Catalog Service listening on ${PORT}`);

});
